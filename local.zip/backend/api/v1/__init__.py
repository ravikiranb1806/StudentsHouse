#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    backend.api.v1
    ~~~~~~~~~~~~~~

    This package contains the API v1 endpoints of this application.
"""

URL = 'api/v1'