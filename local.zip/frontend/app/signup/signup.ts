import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'signup-cmp',
  templateUrl: 'signup.html'
})
export class SignupComponent { 
  name = 'select';
}