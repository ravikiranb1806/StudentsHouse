import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'userhome-cmp',
  templateUrl: 'userhome.html'
})
export class UserhomeComponent { 
    student ='Student';
    accommodator = 'Accommodator';
}