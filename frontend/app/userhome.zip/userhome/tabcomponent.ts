import { Component } from '@angular/core';
import { Tabs } from './tabs';
import { Tab } from './tab';

@Component({
  selector: 'tabcomponent',
  template: `
    <tabs id="tabs">
      <tab [tabTitle]="'Accommodators'">Tab 1 Content</tab>
      <tab tabTitle="Requests">Tab 2 Content</tab>
      <tab tabTitle="Blocked">Tab 3 Content</tab>
      <tab tabTitle="Settings">Tab 4 Content</tab>
    </tabs>
  `
})

export class tabcomponent{

}